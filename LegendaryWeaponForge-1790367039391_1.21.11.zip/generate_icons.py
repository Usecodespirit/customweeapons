import os
import struct
import zlib

SIZE = 32
TRANSPARENT = (0, 0, 0, 0)


def image():
    return [[TRANSPARENT for _ in range(SIZE)] for _ in range(SIZE)]


def pixel(canvas, x, y, color):
    if 0 <= x < SIZE and 0 <= y < SIZE:
        canvas[y][x] = color


def line(canvas, start, end, color, width=1):
    x0, y0 = start
    x1, y1 = end
    dx, dy = abs(x1 - x0), abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    error = dx - dy
    while True:
        for ox in range(-(width // 2), width // 2 + 1):
            for oy in range(-(width // 2), width // 2 + 1):
                pixel(canvas, x0 + ox, y0 + oy, color)
        if x0 == x1 and y0 == y1:
            break
        twice = error * 2
        if twice > -dy:
            error -= dy
            x0 += sx
        if twice < dx:
            error += dx
            y0 += sy


def rect(canvas, x1, y1, x2, y2, color):
    for y in range(y1, y2 + 1):
        for x in range(x1, x2 + 1):
            pixel(canvas, x, y, color)


def outline(canvas, x1, y1, x2, y2, color):
    line(canvas, (x1, y1), (x2, y1), color)
    line(canvas, (x2, y1), (x2, y2), color)
    line(canvas, (x2, y2), (x1, y2), color)
    line(canvas, (x1, y2), (x1, y1), color)


def base_blade(canvas, edge, center, grip):
    line(canvas, (25, 4), (9, 21), edge, 4)
    line(canvas, (24, 5), (10, 20), center, 2)
    line(canvas, (8, 20), (15, 27), grip, 3)
    line(canvas, (5, 25), (12, 18), edge, 2)
    rect(canvas, 12, 26, 16, 29, (54, 37, 28, 255))
    pixel(canvas, 14, 30, (218, 184, 121, 255))


def draw(name):
    c = image()
    if name == 'bloodblade':
        base_blade(c, (85, 11, 27, 255), (225, 49, 65, 255), (39, 18, 25, 255))
        line(c, (20, 9), (13, 16), (255, 130, 135, 255))
        pixel(c, 22, 8, (250, 70, 85, 255))
        line(c, (18, 14), (18, 19), (170, 18, 44, 255), 2)
        pixel(c, 17, 20, (250, 45, 61, 255))
    elif name == 'stormfang':
        base_blade(c, (19, 96, 151, 255), (104, 235, 255, 255), (17, 44, 72, 255))
        line(c, (22, 6), (17, 11), (240, 255, 255, 255), 2)
        line(c, (17, 11), (20, 11), (240, 255, 255, 255), 2)
        line(c, (20, 11), (14, 18), (240, 255, 255, 255), 2)
        line(c, (26, 8), (24, 13), (46, 199, 255, 255))
        pixel(c, 14, 17, (238, 255, 255, 255))
    elif name == 'frostbrand':
        base_blade(c, (123, 215, 245, 255), (242, 255, 255, 255), (53, 100, 133, 255))
        line(c, (21, 8), (15, 16), (220, 250, 255, 255), 2)
        line(c, (15, 16), (12, 11), (177, 235, 255, 255))
        line(c, (15, 16), (21, 17), (177, 235, 255, 255))
        line(c, (19, 12), (17, 7), (255, 255, 255, 255))
        pixel(c, 10, 21, (209, 251, 255, 255))
    elif name == 'voidreaper':
        base_blade(c, (34, 19, 73, 255), (153, 80, 231, 255), (25, 15, 43, 255))
        line(c, (25, 5), (19, 9), (214, 164, 255, 255), 2)
        line(c, (19, 9), (22, 14), (37, 19, 64, 255), 2)
        line(c, (22, 14), (14, 20), (185, 107, 255, 255), 2)
        pixel(c, 25, 7, (226, 192, 255, 255))
        pixel(c, 12, 22, (95, 43, 151, 255))
    else:
        base_blade(c, (177, 83, 18, 255), (255, 219, 92, 255), (104, 51, 15, 255))
        line(c, (24, 4), (18, 10), (255, 250, 182, 255), 2)
        line(c, (18, 10), (23, 11), (255, 250, 182, 255), 2)
        line(c, (23, 11), (15, 19), (255, 250, 182, 255), 2)
        pixel(c, 27, 5, (255, 172, 38, 255))
        pixel(c, 13, 19, (255, 247, 170, 255))
    return c


def png_bytes(canvas):
    raw = b''.join(b'\x00' + bytes(channel for pixel_value in row for channel in pixel_value) for row in canvas)

    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)

    header = struct.pack('>IIBBBBB', SIZE, SIZE, 8, 6, 0, 0, 0)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header) + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b'')


output = os.path.join(os.path.dirname(__file__), 'assets', 'globalweapons', 'textures', 'item')
os.makedirs(output, exist_ok=True)
for weapon in ('bloodblade', 'stormfang', 'frostbrand', 'voidreaper', 'sunbreaker'):
    path = os.path.join(output, weapon + '.png')
    if not os.path.exists(path):
        with open(path, 'wb') as texture:
            texture.write(png_bytes(draw(weapon)))